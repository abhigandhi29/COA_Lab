### Group 22
## Abhishek Gandhi 19CS10031
## Sajal Chhamunya 19CS10051

Create two Block Memory Instruction Memory(Single Block ROM with init data Instructions.coe) and Data Memory(Single Block RAM)

Write binary code in Instructions.coe